package com.checkmarx.flow.config;

public enum FindingSeverity {
    HIGH, MEDIUM, LOW, INFO
}
