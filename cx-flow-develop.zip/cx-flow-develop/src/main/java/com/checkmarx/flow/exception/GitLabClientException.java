package com.checkmarx.flow.exception;


public class GitLabClientException extends MachinaException {
    public GitLabClientException() {
    }

    public GitLabClientException(String message) {
        super(message);
    }
}
