package com.checkmarx.flow.dto;


public abstract class XXIssue {
    public abstract String getVulnType();
    public abstract String getFilename();
}
