package com.checkmarx.flow.exception;

public class IastThatPropertiesIsRequiredException extends RuntimeException {
    public IastThatPropertiesIsRequiredException(String msg) {
        super(msg);
    }
}
