package com.checkmarx.flow.dto;

public class Event {

}
