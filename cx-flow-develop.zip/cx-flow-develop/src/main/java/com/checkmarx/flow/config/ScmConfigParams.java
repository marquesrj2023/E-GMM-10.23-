package com.checkmarx.flow.config;

public enum ScmConfigParams {
    TOKEN, WEBHOOK_TOKEN, API_URL
}