package com.checkmarx.flow.exception;


public class ADOClientException extends MachinaException {
    public ADOClientException() {
    }

    public ADOClientException(String message) {
        super(message);
    }
}
