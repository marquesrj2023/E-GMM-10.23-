package com.checkmarx.flow.exception;

public class CheckmarxLegacyException extends Exception {
    public CheckmarxLegacyException(String message) {
        super(message);
    }
}
