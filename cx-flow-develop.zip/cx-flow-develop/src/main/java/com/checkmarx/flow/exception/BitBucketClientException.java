package com.checkmarx.flow.exception;


public class BitBucketClientException extends MachinaException {
    public BitBucketClientException() {
    }

    public BitBucketClientException(String message) {
        super(message);
    }
}
