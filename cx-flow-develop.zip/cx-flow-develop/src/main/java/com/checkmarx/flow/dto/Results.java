package com.checkmarx.flow.dto;


public abstract class Results {
    public abstract XXIssue getXIssues();
}
