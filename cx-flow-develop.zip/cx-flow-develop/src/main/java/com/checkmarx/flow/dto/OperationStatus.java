package com.checkmarx.flow.dto;

public enum OperationStatus {
    FAILURE,
    SUCCESS
}
