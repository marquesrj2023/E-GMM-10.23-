package com.checkmarx.flow.config;

public enum CliMode{
        SCAN,
        PROJECT
}