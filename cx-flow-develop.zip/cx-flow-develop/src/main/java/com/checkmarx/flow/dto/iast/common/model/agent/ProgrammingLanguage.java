package com.checkmarx.flow.dto.iast.common.model.agent;

import java.io.Serializable;

public enum ProgrammingLanguage implements Serializable {
    JAVA,
    NODE_JS,
    C_SHARP
}
