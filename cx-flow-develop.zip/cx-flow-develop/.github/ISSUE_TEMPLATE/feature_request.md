---
name: Feature request
about: Suggest new functionality for this project.
title: ''
labels: 'enhancement'
assignees: ''

---

### Describe the problem

> A clear description of what the problem is.

### Proposed solution

> A clear description of what you want to happen.

### Additional details

> Add any other details / contexts / screenshots about the feature request.
