const assert = require('assert')
const github = require('../src/github/github')

describe('github', function () {
    /*
    describe('#getIssuesFromXml()', function () {
        let issues = github.getIssuesFromXml(__dirname + "\\samples\\report.xml")
        console.error(issues[0])
        //assert(issues && issues.length > 0)
    })
    describe('#getSummary()', function () {
        let issues = cxgithub.getIssuesFromXml(__dirname + "\\samples\\report.xml")
        let summary = cxgithub.getSummary(issues)
        assert(summary)
    })
    */
})
