# Security Policy

## Reporting a Vulnerability

If you’ve found a vulnerability please open an issue to the repository or use the following link:

https://github.com/checkmarx-ts/checkmarx-github-action/issues/new?assignees=&labels=bug&template=bug_report.md
